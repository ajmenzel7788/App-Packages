﻿If([String](Get-Item -Path "$Env:ProgramFiles\7-Zip\7zFM.exe","${Env:ProgramFiles(x86)}\7-Zip\7zFM.exe" -ErrorAction SilentlyContinue).VersionInfo.FileVersion -ge "26.02"){
Write-Host "Installed"
Exit 0
}
else {
Exit 1
}

﻿## Check for 7-Zip (File Detection Method)
$7ZipExe = (Get-ChildItem -Path "C:\Program Files\7-Zip\7zFM.exe","C:\Program Files (x86)\7-Zip\7zFM.exe" -ErrorAction SilentlyContinue)
$7ZipExe.FullName
$7ZipPath = $($7ZipExe.FullName).Replace("C:\Program Files\","").Replace("C:\Program Files (x86)\","")
$FileVersion = (Get-Item -Path "$($7ZipExe.FullName)" -ErrorAction SilentlyContinue).VersionInfo.FileVersion

## Create Text File with 7-Zip File Detection Method
$FilePath = "C:\Windows\Temp\7-Zip_Detection_Method.txt"
New-Item -Path "$FilePath" -Force
Set-Content -Path "$FilePath" -Value "If([String](Get-Item -Path `"`$Env:ProgramFiles\$7ZipPath`",`"`${Env:ProgramFiles(x86)}\$7ZipPath`" -ErrorAction SilentlyContinue).VersionInfo.FileVersion -ge `"$FileVersion`"){"
Add-Content -Path "$FilePath" -Value "Write-Host `"Installed`""
Add-Content -Path "$FilePath" -Value "Exit 0"
Add-Content -Path "$FilePath" -Value "}"
Add-Content -Path "$FilePath" -Value "else {"
Add-Content -Path "$FilePath" -Value "Exit 1"
Add-Content -Path "$FilePath" -Value "}"
Invoke-Item $FilePath

